import win32gui,win32process
from time import sleep
import psutil
import os


def get_window_pid(title):
    hwnd = win32gui.FindWindow(None, title)
    threadid,pid = win32process.GetWindowThreadProcessId(hwnd)
    return pid


def kill_peerflix():
    for x in range(20):
        try:
            PID = get_window_pid('peerflix') 

            if (PID) > 0:
                p = psutil.Process(PID)
                p.terminate()
                print('fim')
        except:
            pass


def start_peerflix(magnetic):
    kill_peerflix()
    sleep(5)
    magnetic = '"' + magnetic + '"'
    os.popen(f'start cmd /k peerflix {magnetic}')



    

